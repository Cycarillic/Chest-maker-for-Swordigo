#Made by Cycarillic
#-Made on: 06/03/2025  (DD-MM-YYYY)
import INPUT
obj = INPUT.obj
x = INPUT.x
y = INPUT.y
z = INPUT.z
r = INPUT.r
s = INPUT.s
cyname = INPUT.cyname
amount = INPUT.amount
item_name = INPUT.item_name
item_identifier = INPUT.item_identifier
#---------------------------------------------------------
#---------------DO NOT EDIT THE CODE BELOW----------------
#---------------------------------------------------------

#-Format for chests. ---DO NOT EDIT---
format = {
"object" : {
    "name" : obj,
    "identifier" : cyname,
    "component" : {
        "component_type" : 'ItemDrop',
        "number" : 112,
        "item_drop" : {
            "item" : {
                "object" : item_name,
                "identifier" : item_identifier,
                "u0" : 1.0,
                "u1" : 1,
                "amount" : amount,
            }
            ,"u0" : 1,
            "u1" : 0,
        }
        ,"position" : {
            "x_position" : x,
            "y_position" : y,
        } 
        ,'z_position' : z,
        "rotation" : r,
        "scale" : s,
        "u2" : {
            "w" : -80.0,
            "x" : -25.0,
            "y" : 110.0,
            "z" : 57.6,
        }
        ,"hidden" : 0,
    }
}
}

