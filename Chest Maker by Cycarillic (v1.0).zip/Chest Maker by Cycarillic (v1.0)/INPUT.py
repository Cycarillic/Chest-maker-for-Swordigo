#Made by Cycarillic
#-Made on: 07/03/2025  (DD-MM-YYYY)
#input values here (do not change var name)
#DO NOT REMOVE THE SINGLE QUOTATION MARK PUT THE VALUES IN THE SINGLE QUOTES like this : example = "'value'" to example = "'chest_left'" 
obj = "'chest_left'"   #put the chests name (must be either : chest_left or chest_right)
x = 100
y = 50
z = 0
r = 0
s = 1
cyname = "'chestleft'"  #CHEST IDENTIFIER NAME
amount = 1
item_name = "'sshard_red'"
item_identifier = "'shardred'"