#Made by Cycarillic
#-Made on: 08/03/2025  (DD-MM-YYYY)

#----------------------------------------------------OPTIONS--------------------------------------------------------
showformat = True  #Show the format when the file is ran, Made for the true Swordigo modders
showINPUTtokens = True  #Show tokens created after the tokenization 
showFORMATtokens = True #Show format tokens after the tokennization
preventexit = True #Prevents the terminal from closing after running the script (For the people running this in cmd)
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
import chestformat
import INPUT
import time
#All the vars after importing from INPUT.py file
obj = INPUT.obj
objx = INPUT.x
objy = INPUT.y
objz = INPUT.z
objr = INPUT.r
objs = INPUT.s
name = INPUT.cyname
a = INPUT.amount
CYformat = chestformat.format
item_name = INPUT.item_name
item_identifier = INPUT.item_identifier



if showformat == True:
    print(CYformat)
    print("")


tokens = []   #this list holds the tokens  from the input
formatlist = [] #this list holds the tokens from the format


#Tokenization process

class token:   #Class 'token' is created 
    def __init__(self , chobj , x , y , z , r , s , cyname , amount , item_name , item_identifier):  # function holding token values and data , here "self" is the object to be created, this allows us to access the tokens that get created.
        self.chobj = chobj   #object data is made equal to object
        self.x = x        # x data is made equal to x
        self.y = y        #y data  is made equal to y
        self.z = z        #z data is made equal to z
        self.r = r        #r data is made equal to r
        self.s = s         #s data is made equal to s
        self.cyname = cyname   #cyname is made equal cyname
        self.amount = amount     #you know it now bro
        self.item_name = item_name
        self.item_identifier = item_identifier


CYstr = token(obj , objx , objy , objz , objr , objs , name , a , item_name , item_identifier)  #CYstr (idk y I named it that) assigns the token appropriate values based on the vars assigned to them. It also allows us use the tokens individually.

def tokenizer():
    print("TOKENIZING")
    print("::::::::::")
    #Here we add the tokens to the "tokens" list and then print the list if showtokens is true.
    tokens.append(CYstr.chobj) 
    tokens.append(CYstr.x)
    tokens.append(CYstr.y)
    tokens.append(CYstr.z)
    tokens.append(CYstr.r)
    tokens.append(CYstr.s)
    tokens.append(CYstr.cyname)
    tokens.append(CYstr.amount)
    tokens.append(CYstr.item_name)
    tokens.append(CYstr.item_identifier)

    if showINPUTtokens == True:
        time.sleep(0.5)
        print(tokens)
    print("Tokenized")
    print(":::::::::")
    
tokenizer()
print("Tokenizing Format")
print(":::::::::::::::::::::::::::::::::::::::::::::::::::")

#Same process for the tokenization
class frmt:                                                                                                                         #u0    u1    #amount
    def __init__(self , object , name , identifier , component , component_type , number , item_drop , item , object1 , identifier1 , u01 , u11 , quantity , u02 , u12 , position , x_position , y_position , z_position , rotation , scale , u2 , w , x , y ,z , hidden):
        self.object = obj
        self.name = name
        self.identifier = identifier
        self.component = component
        self.component_type = component_type
        self.number = number
        self.item_drop = item_drop
        self.item = item
        self.object1 = object1
        self.identifier1 = identifier1
        self.u01 = u01
        self.u11 = u11
        self.quantity = quantity
        self.u02 = u02
        self.u12 = u12
        self.position = position
        self.x_position = x_position
        self.y_position = y_position
        self.z_position = z_position
        self.rotation = rotation
        self.scale = scale
        self.u2 = u2
        self.w = w
        self.x = x
        self.y = y
        self.z = z
        self.hidden = hidden

fmt = frmt("object" , "name" , "identifier" , "component" , "component_type" , "number" , "item_drop" , "item" , "object" , "identifier" , "u0" , "u1" , "amount" , "u0" , "u1" , "position" , "x_position" , "y_position" , "z_position" , "rotation" , "scale" , "u2" , "w" , "x" , "y" , "z" , "hidden" )

def format_tokennizer():   #Adding the tokens in a list (formatist)
    formatlist.append(fmt.object)
    formatlist.append(fmt.name)
    formatlist.append(fmt.identifier)
    formatlist.append(fmt.component)
    formatlist.append(fmt.component_type)
    formatlist.append(fmt.number)
    formatlist.append(fmt.item_drop)
    formatlist.append(fmt.item)
    formatlist.append(fmt.object1)
    formatlist.append(fmt.identifier1)
    formatlist.append(fmt.u01)
    formatlist.append(fmt.u11)
    formatlist.append(fmt.quantity)
    formatlist.append(fmt.u02)
    formatlist.append(fmt.u12)
    formatlist.append(fmt.position)
    formatlist.append(fmt.x_position)
    formatlist.append(fmt.y_position)
    formatlist.append(fmt.z_position)
    formatlist.append(fmt.rotation)
    formatlist.append(fmt.scale)
    formatlist.append(fmt.u2)
    formatlist.append(fmt.w)
    formatlist.append(fmt.x)
    formatlist.append(fmt.y)
    formatlist.append(fmt.z)
    formatlist.append(fmt.hidden)


format_tokennizer()

if showFORMATtokens == True:
    
    print(formatlist)

print(":::::::::::::::::::::::::::::::::::::::::::::::::::")
print("Format tokenized")


def PARSER():
    print("")
    print("RUNNING THE PARSER")
    time.sleep(0.5)
#{{}} here allows us to use {} like strings in "" and {} is used to put vars to print them.
    print(f"""

{fmt.object} {{              
    {fmt.name} : {CYstr.chobj},
    {fmt.identifier} : {CYstr.cyname},
    {fmt.component} {{
        {fmt.component_type} : 'item_drop',
        {fmt.number} : 112,
        {fmt.item_drop} {{
            {fmt.item} {{
                {fmt.object1} : {CYstr.item_name},
                {fmt.identifier1} : {CYstr.item_identifier},
                {fmt.u01} : 1.0,
                {fmt.u11} : 1,
                {fmt.quantity} : {CYstr.amount},
            }}
            {fmt.u02} : 1,
            {fmt.u12} : 0,
        }}
        {fmt.position} {{
            {fmt.x_position} : {CYstr.x},
            {fmt.y_position} : {CYstr.y},
        }}
        {fmt.z_position} : {CYstr.z},
        {fmt.rotation} : {CYstr.r},
        {fmt.scale} : {CYstr.s},
        {fmt.u2} {{
            {fmt.w} : -80.0,
            {fmt.x} : -25.0,
            {fmt.y} : 110.0,
            {fmt.z} : 57.6,
        }}
        {fmt.hidden} : 0,
    }}
}}

""")

PARSER()


if preventexit == True:
    time.sleep(999999)